#!/bin/bash
# 1-Click Launch Helper for lidZen
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Starting lidZen..."
xattr -cr "$DIR/lidZen.app" 2>/dev/null || true
open "$DIR/lidZen.app"
osascript -e 'tell application "Terminal" to close (every window whose name contains "Open lidZen")' 2>/dev/null || true
